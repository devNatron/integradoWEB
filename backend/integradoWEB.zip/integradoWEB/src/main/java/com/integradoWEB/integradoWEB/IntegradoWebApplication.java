package com.integradoWEB.integradoWEB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegradoWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntegradoWebApplication.class, args);
	}

}
